package pack;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JPanel;

public class Dessin extends JPanel implements Runnable {

	private static final long serialVersionUID = 1L;

	private final double TAILLE = 40.0;
	private final double NB_RADIANS = 0.2;
	private final double DEPLACEMENT = 2.5;
	private final long TEMPS = 70;

	private boolean avecRotation = false;
	private boolean clic = false;
	private boolean enCoursDAnimation = false;

	private int xPos;
	private int yPos;

	private double degreRota = 0.;

	public Dessin() {
		setBackground(Color.black);

		addMouseListener(new MouseAdapter() {

			public void mousePressed(MouseEvent e) {
				if ((e.getX() < ((getWidth() / 2.) - (TAILLE / 2.)) && (e.getX() > TAILLE / 2.))) {
					clic = true;
					yPos = e.getY();
					xPos = e.getX();
					repaint();
				}
			}
		});

	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;

		g2d.setColor(Color.yellow);
		Line2D.Double ligne = new Line2D.Double(getWidth() / 2, 0, getWidth() / 2, getHeight());
		g2d.draw(ligne);

		Rectangle2D.Double recRouge;
		Rectangle2D.Double recVert;

		if (clic == true) {

			if (avecRotation == false) {

				g2d.setColor(Color.red);
				recRouge = new Rectangle2D.Double(xPos - TAILLE / 2., yPos - TAILLE / 2., TAILLE, TAILLE);
				g2d.fill(recRouge);

				g2d.setColor(Color.green);
				recVert = new Rectangle2D.Double(
						((xPos - TAILLE / 2.) + (((getWidth()) - (2. * (xPos - TAILLE / 2.))))) - (TAILLE),
						yPos - TAILLE / 2., TAILLE, TAILLE);
				g2d.fill(recVert);

			}
			if (avecRotation == true) {

				AffineTransform original = g2d.getTransform();
				g2d.rotate(degreRota, xPos, yPos);
				g2d.setColor(Color.red);
				recRouge = new Rectangle2D.Double(xPos - TAILLE / 2., yPos - TAILLE / 2., TAILLE, TAILLE);
				g2d.fill(recRouge);
				g2d.setTransform(original);

				original = g2d.getTransform();
				g2d.rotate(degreRota, xPos + (2. * ((getWidth() / 2.) - xPos)), yPos);
				g2d.setColor(Color.green);
				recVert = new Rectangle2D.Double(
						((xPos - TAILLE / 2.) + ((getWidth()) - (2. * (xPos - TAILLE / 2.)))) - (TAILLE),
						yPos - TAILLE / 2., TAILLE, TAILLE);
				g2d.fill(recVert);
				g2d.setTransform(original);

			}
		}

	}

	@Override
	public void run() {
		while (enCoursDAnimation) {
			yPos += DEPLACEMENT;
			if (yPos > getHeight() + TAILLE) {
				arreter();
				degreRota = 0.0;
				avecRotation = false;
				clic = false;
			}
			if (avecRotation == true) {
				degreRota += NB_RADIANS;
			}
			repaint();

			try {
				Thread.sleep(TEMPS);
			} catch (InterruptedException e) {
				System.out.println("Processus interrompu!");
			}
		}
	}

	public void setAvecRotation(boolean avecRotation) {
		this.avecRotation = avecRotation;
	}

	public void demarrer() {
		if (enCoursDAnimation == false) {
			Thread processusAnim = new Thread(this);
			processusAnim.start();
			enCoursDAnimation = true;
		}
	}

	public void arreter() {
		enCoursDAnimation = false;
	}

}

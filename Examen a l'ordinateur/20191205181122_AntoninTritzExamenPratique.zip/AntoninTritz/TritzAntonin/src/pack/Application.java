package pack;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;

public class Application extends JFrame {

	private static final long serialVersionUID = -3811610953957373538L;
	private JPanel contentPane;
	private Dessin dessin1;
	private Dessin dessin2;

	private final ButtonGroup rdbtnGroupe = new ButtonGroup();
	private JRadioButton rdbtnAvecRota;
	private JRadioButton rdbtnSansRota;
	private JButton btnAnimer;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Application frame = new Application();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Application() {

		setTitle("Antonin Tritz");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 520);
		contentPane = new JPanel();
		contentPane.setBackground(Color.white);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblAnimation = new JLabel("Animation:");
		lblAnimation.setBounds(10, 456, 90, 14);
		contentPane.add(lblAnimation);

		btnAnimer = new JButton("Animer!");
		btnAnimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dessin1.demarrer();
				dessin2.demarrer();
			}
		});

		btnAnimer.setBounds(368, 452, 134, 23);
		contentPane.add(btnAnimer);

		rdbtnSansRota = new JRadioButton("Sans rotation");
		rdbtnSansRota.setSelected(true);
		rdbtnSansRota.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dessin1.setAvecRotation(false);
				dessin2.setAvecRotation(false);
			}
		});

		rdbtnSansRota.setBounds(231, 452, 109, 23);
		contentPane.add(rdbtnSansRota);
		rdbtnGroupe.add(rdbtnSansRota);

		rdbtnAvecRota = new JRadioButton("Avec rotation");
		rdbtnAvecRota.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dessin1.setAvecRotation(true);
				dessin2.setAvecRotation(true);
			}
		});

		rdbtnAvecRota.setBounds(97, 452, 109, 23);
		contentPane.add(rdbtnAvecRota);
		rdbtnGroupe.add(rdbtnAvecRota);

		dessin1 = new Dessin();
		dessin1.setBounds(10, 23, 492, 400);
		contentPane.add(dessin1);

		dessin2 = new Dessin();
		dessin2.setBounds(512, 23, 162, 100);
		contentPane.add(dessin2);

	}
}
